package org.example.service;

public interface BookingService {
    public void bookTaxi();
    public void displayTaxiDetails();
    public void setTaxi(int n);
}
